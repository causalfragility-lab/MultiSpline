#' Intraclass correlation coefficients for a multilevel nl_fit model
#'
#' @description
#' Extracts variance components from a multilevel \code{nl_fit} object and
#' computes intraclass correlation coefficients (ICCs) for each grouping level
#' plus the residual.
#'
#' The ICC for grouping factor \eqn{g} is defined as:
#' \deqn{ICC_g = \frac{\sigma^2_g}{\sum_j \sigma^2_j + \sigma^2_\epsilon}}
#'
#' @param object An \code{nl_fit} object returned by \code{\link{nl_fit}} that
#'   was fitted with one or more \code{cluster} variables (i.e., a multilevel
#'   model fitted via \code{lme4::lmer()} or \code{lme4::glmer()}).
#'
#' @return A named numeric vector of ICCs, one per grouping factor
#'   (named \code{ICC_<groupname>}) plus \code{ICC_resid} for the residual
#'   variance. All values sum to 1.
#'
#' @examples
#' \dontrun{
#' fit <- nl_fit(
#'   data    = mydata,
#'   y       = "math_score",
#'   x       = "SES",
#'   cluster = c("id", "schid"),
#'   df      = 4
#' )
#' nl_icc(fit)
#' #>  ICC_id  ICC_schid  ICC_resid
#' #>  0.40    0.20       0.40
#' }
#'
#' @seealso \code{\link{nl_fit}}
#'
#' @export
nl_icc <- function(object) {
  # ---------------------------------------------------------------------------
  # Input checks
  # ---------------------------------------------------------------------------
  if (!inherits(object, "nl_fit")) {
    stop("`object` must be an 'nl_fit' object produced by nl_fit().", call. = FALSE)
  }
  
  mod <- object$model
  
  if (!inherits(mod, c("lmerMod", "glmerMod"))) {
    stop(
      "`nl_icc()` requires a multilevel model. ",
      "Refit nl_fit() with one or more `cluster` variables.",
      call. = FALSE
    )
  }
  
  # ---------------------------------------------------------------------------
  # Extract variance components
  # ---------------------------------------------------------------------------
  vc    <- lme4::VarCorr(mod)
  vc_df <- as.data.frame(vc)
  
  # Residual variance (sigma^2 for lmerMod; on link scale approx for glmerMod)
  sigma_val <- attr(vc, "sc")
  if (is.null(sigma_val) || !is.finite(sigma_val)) {
    # fallback for glmerMod where sc may be 1
    sigma_val <- 1
  }
  v_resid <- sigma_val^2
  
  # Keep only random-intercept variances (var1 == "(Intercept)", no var2)
  re <- vc_df[
    !is.na(vc_df$var1) & vc_df$var1 == "(Intercept)" & is.na(vc_df$var2),
    c("grp", "vcov"),
    drop = FALSE
  ]
  
  if (nrow(re) == 0L) {
    stop("No random intercept variance components found in the model.", call. = FALSE)
  }
  
  # ---------------------------------------------------------------------------
  # Compute ICCs
  # ---------------------------------------------------------------------------
  total <- sum(re$vcov) + v_resid
  
  if (!is.finite(total) || total <= 0) {
    stop("Total variance is non-positive or non-finite. Cannot compute ICCs.", call. = FALSE)
  }
  
  icc_levels <- stats::setNames(re$vcov / total, paste0("ICC_", re$grp))
  icc_resid  <- c(ICC_resid = v_resid / total)
  
  out <- c(icc_levels, icc_resid)
  
  # sanity check: should sum to ~1
  if (abs(sum(out) - 1) > 1e-6) {
    warning("ICC components do not sum to 1 (sum = ", round(sum(out), 6), "). ",
            "This may indicate a non-standard model structure.", call. = FALSE)
  }
  
  out
}