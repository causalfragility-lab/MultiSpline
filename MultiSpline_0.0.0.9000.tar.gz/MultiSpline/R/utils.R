# ---------------------------------------------------------------------------
# Package-level import declarations
# These tell roxygen2 to add importFrom lines to NAMESPACE
# ---------------------------------------------------------------------------

#' @importFrom splines ns
NULL

#' @importFrom rlang .data
NULL


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

# NULL-coalescing operator (internal, no documentation generated)
# Returns a if not NULL, otherwise b.
`%||%` <- function(a, b) if (!is.null(a)) a else b 